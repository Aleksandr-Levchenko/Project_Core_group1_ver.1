# Project_Core_group1_ver.1
CLI - Command Line Interface bot
